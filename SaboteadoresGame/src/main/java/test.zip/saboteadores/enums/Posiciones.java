package saboteadores.enums;

public enum Posiciones{
	ARRIBA, ABAJO, IZQUIERDA, DERECHA, NO
}
