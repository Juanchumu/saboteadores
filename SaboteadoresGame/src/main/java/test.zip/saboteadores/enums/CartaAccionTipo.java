package saboteadores.enums;

public enum CartaAccionTipo{
	PICO, ANTORCHA, MINECART,  VACIO
}
