package saboteadores.enums;
public enum CartaTipo{
	ACCION, CAMINO, REVERSO, CALLEJON, SABOTAJE, REPARACION, VISTA, DERRUMBE
}
