package saboteadores.enums;
public enum Rol{
	IMPOSTOR, ENANO
}
