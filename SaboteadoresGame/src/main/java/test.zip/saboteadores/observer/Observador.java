package saboteadores.observer;

public interface Observador {
	void actualizar();
}
