package saboteadores.mazo.cartas;

import saboteadores.enums.CartaTipo;
public class Carta_Accion extends Carta{
	public Carta_Accion(CartaTipo tipo){
		super(tipo);
	}
}
